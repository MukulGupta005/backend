package com.sports.app.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.sports.app.Service.SearchService;

import com.sports.app.model.Profile;

@RestController
@RequestMapping("/search")
public class SearchController {

    private final SearchService searchService;

    public SearchController(SearchService searchService) {
        this.searchService = searchService;
    }

    @GetMapping
    public ResponseEntity<List<Profile>> searchProfiles(@RequestParam String location, @RequestParam String sport) {
        List<Profile> profiles = searchService.searchProfilesByLocationAndSport(location, sport);
        return ResponseEntity.ok(profiles);
    }
}

