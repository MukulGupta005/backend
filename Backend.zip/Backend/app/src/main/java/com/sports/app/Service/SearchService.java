package com.sports.app.Service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.sports.app.Repository.LocationRepository;
import com.sports.app.Repository.ProfileRepository;
import com.sports.app.model.Location;
import com.sports.app.model.Profile;
import com.sports.app.model.Sport;

@Service
public class SearchService {
    private final ProfileRepository profileRepository;
    private LocationRepository locationRepository;


    public SearchService(ProfileRepository profileRepository) {
        this.profileRepository = profileRepository;
    }
    public List<Profile> searchProfilesByLocationAndSport( String sport) {
        // Convert the location and sport strings to Location and Sport objects
        Sport searchSport = createSport(sport);
    
        // Use the correct method signature in ProfileRepository
        return searchProfiles( searchSport);
    }
    public List<Profile> searchProfilesByLocationAndSport(String city, String sport) {
        // Convert the location and sport strings to Location and Sport objects
        Location searchLocation = new Location();
        searchLocation.setCity(city);
        locationRepository.save(searchLocation); // Save the location object first

        Sport searchSport = new Sport(null, sport);

        // Use the correct method signature in ProfileRepository
        return profileRepository.findByLocationAndSportsContaining(searchSport);
    }
    
    
    private Sport createSport(String sport) {
        return new Sport(null, sport);
    }
    
    private List<Profile> searchProfiles(Sport searchSport) {
        return profileRepository.findByLocationAndSportsContaining( searchSport);
    }
}
 