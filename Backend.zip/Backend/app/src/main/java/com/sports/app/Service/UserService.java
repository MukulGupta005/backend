package com.sports.app.Service;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.sports.app.Repository.UserRepository;
import com.sports.app.model.Location;
import com.sports.app.model.Profile;
import com.sports.app.model.Sport;
import com.sports.app.model.User;
import com.sports.app.Repository.LocationRepository;
import com.sports.app.Repository.ProfileRepository;

@Service
public class UserService {
    private final UserRepository userRepository;
    private final ProfileRepository profileRepository;
    private final LocationRepository locationRepository;

    public UserService(UserRepository userRepository, ProfileRepository profileRepository, LocationRepository locationRepository) {
        this.userRepository = userRepository;
        this.profileRepository = profileRepository;
        this.locationRepository = locationRepository;
    }

    public User registerUser(User user) {
        // Assuming the Profile and Location are part of the User object
        Profile profile = user.getProfile();
        Location location = profile.getLocation();

        // Save the Location entity first
        location = locationRepository.save(location);
        profile.setLocation(location); // Update the Profile with the saved Location

        // Now save the Profile entity
        profile = profileRepository.save(profile);
        user.setProfile(profile); // Update the User with the saved Profile

        // Finally, save the User entity
        return userRepository.save(user);
    }
    public User signUpWithEmailPasswordName(String email, String password, String name ) {
    // Create a new User object
    User user = new User();
    user.setEmail(email);
    user.setPassword(password);
    user.setName(name);

    // Create a new Profile object with the given user information
    Profile profile = new Profile();
    profile.setInterests("Enter Your Interest"); // Set interests instead of name
    profile.setLocation(null);
    user.setProfile(profile);

    // Create a new Location object with default values
    Location location = new Location();
    profile.setLocation(location);

    // No specific sports have been provided, so we initialize the set with an empty list
    Set<Sport> sports = new HashSet<>();
    profile.setSports(sports);

    // Save the user using the UserService's registerUser method
    UserService userService = new UserService(userRepository, profileRepository, locationRepository);
    return userService.registerUser(user);
}
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    public User updateProfile(Profile profile) {
        // Assuming you have a method to find the user by profile
        User user = userRepository.findByProfile(profile);
        if (user != null) {
            user.setProfile(profile);
            return userRepository.save(user);
        }
        return null;
    }

    public User signUpWithEmailPasswordName(User user) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'signUpWithEmailPasswordName'");
    }
}
