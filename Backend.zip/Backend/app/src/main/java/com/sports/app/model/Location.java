package com.sports.app.model;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class Location {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String city;
    
    public Location(String city) {
        this.city = city;
        // Assuming the city string contains latitude and longitude
        // You might need to parse the city string to extract these values
        // For demonstration, let's assume they are hardcoded
        // this.latitude = 40.7128; // Example latitude
        // this.longitude = -74.0060; // Example longitude
    }
    
    // Getters and setters
}