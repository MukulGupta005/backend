package com.sports.app.Service;

import org.springframework.stereotype.Service;

import com.sports.app.Repository.ProfileRepository;
import com.sports.app.model.Profile;

@Service
public class ProfileService {
    private final ProfileRepository profileRepository;

    
    public ProfileService(ProfileRepository profileRepository) {
        this.profileRepository = profileRepository;
    }

    public Profile createProfile(Profile profile) {
        return profileRepository.save(profile);
    }

    public Profile updateProfile(Profile profile) {
        return profileRepository.save(profile);
    }
}
