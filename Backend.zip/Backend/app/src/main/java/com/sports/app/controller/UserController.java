package com.sports.app.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.sports.app.Service.UserService;
import com.sports.app.model.Profile;
import com.sports.app.model.User;

@RestController
@RequestMapping("/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/signup")
    public ResponseEntity<User> registerUser(@RequestBody User user) {
        // Set default values for profile and other optional fields
        user.setProfile(new Profile());
        // Save the user to the database
        User savedUser = userService.signUpWithEmailPasswordName(user.getEmail(), user.getPassword(), user.getName());
        return new ResponseEntity<>(savedUser, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<User> updateProfile(@PathVariable Long id, @RequestBody Profile profile) {
        User updatedUser = userService.updateProfile(profile);
        return ResponseEntity.ok(updatedUser);
    }
    @GetMapping("/all")
    public List<User> getAllUsers() {
        return userService.getAllUsers();
    }
}

